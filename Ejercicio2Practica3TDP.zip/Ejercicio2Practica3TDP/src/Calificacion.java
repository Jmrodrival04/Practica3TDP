public class Calificacion {
    private String usuarioId;
    private String libroId;
    private int calificacion;

}
