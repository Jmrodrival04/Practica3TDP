public interface AnalizadorDeSentimiento {
    String analizarSentimiento(String texto);

}
