public class Publicacion {
    private String texto;

    public Publicacion(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}

